




CDNL = function(data1,data2,index,boot_strap=10,threshold=5,cores=4,
                alpha_min=0,alpha_max=1,lam_min=0.001,lam_max=2,nalpha=4,nlambda=5,fold=3){
  
  X11_w = data1[[1]];X12_w = data1[[2]]
  X21_w = data2[[1]];X22_w = data2[[2]]
  
  N11 = length(X11_w);N12=length(X12_w);N21=length(X21_w);N22=length(X22_w)
  N11tr = ceiling(N11/2); N12tr=ceiling(N12/2); N21tr=ceiling(N21/2); N22tr=ceiling(N22/2)
  N11ts = N11-N11tr;N12ts = N12-N12tr;N21ts = N21-N21tr;N22ts = N22-N22tr
  
  train1 = N11tr+N12tr
  train2 = N21tr+N22tr
  test1 = N11ts+N12ts
  test2 = N21ts+N22ts
  
  train_all = train1+train2
  test_all = test1+test2
  
  p=nrow(X11_w[[1]]); q = ncol(X11_w[[1]])
  
  # parallel computing
  cl <- parallel::makeCluster(getOption("cl.cores",cores))
  doParallel::registerDoParallel(cl)
  # compute precision matrix
  X11_omega <- foreach(i = 1:N11, .errorhandling = 'pass', .packages = "DensParcorr") %dopar% {
    X11.clime <- DensParcorr(t(X11_w[[i]]),dens.level =.5,select=TRUE)
    X11_omega <- X11.clime$selected.precision
    return(X11_omega)
  }
  X12_omega <- foreach(i = 1:N12, .errorhandling = 'pass', .packages = "DensParcorr") %dopar% {
    X12.clime <- DensParcorr(t(X12_w[[i]]),dens.level =.5,select=TRUE)
    X12_omega <- X12.clime$selected.precision
    return(X12_omega)
  }
  X21_omega <- foreach(i = 1:N21, .errorhandling = 'pass', .packages = "DensParcorr") %dopar% {
    X21.clime <- DensParcorr(t(X21_w[[i]]),dens.level =.5,select=TRUE)
    X21_omega <- X21.clime$selected.precision
    return(X21_omega)
  }
  X22_omega <- foreach(i = 1:N22, .errorhandling = 'pass', .packages = "DensParcorr") %dopar% {
    X22.clime <- DensParcorr(t(X22_w[[i]]),dens.level =.5,select=TRUE)
    X22_omega <- X22.clime$selected.precision
    return(X22_omega)
  }
  parallel::stopCluster(cl)
  closeAllConnections()
  # fisher transformation
  mut_in_f<-function(x){
    1/2*log((1+x)/(1-x))
  }
  W11<-lapply(lapply(X11_omega,cov2cor),mut_in_f)
  W12<-lapply(lapply(X12_omega,cov2cor),mut_in_f)
  W21<-lapply(lapply(X21_omega,cov2cor),mut_in_f)
  W22<-lapply(lapply(X22_omega,cov2cor),mut_in_f)
  
  # generate data for logistic regression
  X11_vec<-matrix(nrow=N11,ncol=p*(p-1)/2)
  W11_vec <- array()
  X12_vec<-matrix(nrow=N12,ncol=p*(p-1)/2)
  W12_vec <- array()
  X11_stack<-matrix(nrow=N11,ncol=(p*p))
  W11_stack <- array()
  X12_stack<-matrix(nrow=N12,ncol=(p*p))
  W12_stack <- array()
  
  X21_vec<-matrix(nrow=N21,ncol=p*(p-1)/2)
  W21_vec <- array()
  X22_vec<-matrix(nrow=N22,ncol=p*(p-1)/2)
  W22_vec <- array()
  X21_stack<-matrix(nrow=N21,ncol=(p*p))
  W21_stack <- array()
  X22_stack<-matrix(nrow=N22,ncol=(p*p))
  W22_stack <- array()
  for (i in 1:N11){
    W11_vec <- as.vector(W11[[i]][upper.tri(W11[[i]], diag = FALSE)])
    X11_vec[i,] <- c(W11_vec)
    W11_stack <- as.vector(W11[[i]])
    X11_stack[i,] <- c(W11_stack)
  }
  for (i in 1:N12){
    W12_vec <- as.vector(W12[[i]][upper.tri(W12[[i]], diag = FALSE)])
    X12_vec[i,] <- c(W12_vec)
    W12_stack <- as.vector(W12[[i]])
    X12_stack[i,] <- c(W12_stack)
  }
  for (i in 1:N21){
    W21_vec <- as.vector(W21[[i]][upper.tri(W21[[i]], diag = FALSE)])
    X21_vec[i,] <- c(W21_vec)
    W21_stack <- as.vector(W21[[i]])
    X21_stack[i,] <- c(W21_stack)
  }
  for (i in 1:N22){
    W22_vec <- as.vector(W22[[i]][upper.tri(W22[[i]], diag = FALSE)])
    X22_vec[i,] <- c(W22_vec)
    W22_stack <- as.vector(W22[[i]])
    X22_stack[i,] <- c(W22_stack)
  }
  for (i in 1:p) {
    X11_stack <- X11_stack[,-((i-1)*p+1)]
    X12_stack <- X12_stack[,-((i-1)*p+1)]
    X21_stack <- X21_stack[,-((i-1)*p+1)]
    X22_stack <- X22_stack[,-((i-1)*p+1)]
  }
  
  # training set
  tr11 <- sample(1:N11,N11tr,replace = F)
  tr12 <- sample(1:N12,N12tr,replace = F)
  tr21 <- sample(1:N21,N21tr,replace = F)
  tr22 <- sample(1:N22,N22tr,replace = F)
  
  
  # tuning parameter
  alpha  <- seq(alpha_min, alpha_max, len = nalpha)
  lambda <- seq(lam_min, lam_max, len = nlambda)
  
  para <- matrix(nrow=1,ncol=3)
  K=fold
  for (para1 in 1:K) {
    for (para2 in 1:nalpha) {
      for (para3 in 1:nlambda) {
        para_ori <- c(para1,alpha[para2],lambda[para3])
        para <- rbind(para,para_ori)
      }
    }
  }
  para <- para[-1,]
  rownames(para) <- NULL
  
  # bootstrap
  beta_raw <- matrix(NA,boot_strap,3*p*(p-1))
  a <- matrix(nrow=boot_strap,ncol=(p*(p-1)*m*3/2))
  Y_pre <- matrix(nrow=boot_strap,ncol=test_all)
  Y_pre.vote<-array()
  for (j in 1:boot_strap) {
    ids11 <- sample(tr11, N11tr, replace=T)
    ids12 <- sample(tr12, N12tr, replace=T)
    ids21 <- sample(tr21, N21tr, replace=T)
    ids22 <- sample(tr22, N22tr, replace=T)
    
    #training data
    X1_vec <- cbind(rbind(X11_stack[ids11,],X12_stack[ids12,]),rbind(X11_vec[ids11,],X12_vec[ids12,]))
    X2_vec <- cbind(rbind(X21_stack[ids21,],X22_stack[ids22,]),rbind(X21_vec[ids21,],X22_vec[ids22,]))
    X_vec <- as.matrix(bdiag(X1_vec,X2_vec))
    
    Y1_vec <- array(c(rep(0,N11tr),rep(1,N12tr)),dim = c(train1,1))
    Y2_vec <- array(c(rep(0,N21tr),rep(1,N22tr)),dim = c(train2,1))
    Y_vec <- array(c(Y1_vec,Y2_vec),dim = c(train_all,1))
    
    data.trn <- list(x=X_vec,y=Y_vec)
    #test data
    X1_tst <- cbind(rbind(X11_stack[-tr11,],X12_stack[-tr12,]),rbind(X11_vec[-tr11,],X12_vec[-tr12,]))
    X2_tst <- cbind(rbind(X21_stack[-tr21,],X22_stack[-tr22,]),rbind(X21_vec[-tr21,],X22_vec[-tr22,]))
    X_tst <- as.matrix(bdiag(X1_tst,X2_tst))
    
    Y1_tst <- array(c(rep(0,nrow(X11_vec[-tr11,])),rep(1,nrow(X12_vec[-tr12,]))),dim = c(nrow(X1_tst),1))
    Y2_tst <- array(c(rep(0,nrow(X21_vec[-tr21,])),rep(1,nrow(X22_vec[-tr22,]))),dim = c(nrow(X2_tst),1))
    Y_tst <- array(c(Y1_tst,Y2_tst),dim = c(nrow(X_tst),1))
    
    # CV
    cv <- gen.cv.idx(nrow(X_vec), K)
    LLdiff_all = c()
    for (i in 1:dim(para)[1]){
      k <- para[i,1]
      alpha_i  <- para[i,2]
      lambda_i <- para[i,3]
      data.trn.cv <- list(x=X_vec[cv[[k]]$train, ],y=Y_vec[cv[[k]]$train])
      fit1 <- SGL(data.trn.cv, index, type = "logit", maxit = 1000, thresh = 0.001,
                  min.frac = 0.05, nlam=1, gamma = 0.8, standardize = FALSE,
                  verbose = FALSE, step = 1, reset = 10, alpha = alpha_i, lambdas = lambda_i)
      data.tst.cv <- list(x=X_vec[cv[[k]]$test, ],y=Y_vec[cv[[k]]$test])
      LL_loss <- loglikelihood_SGL(fit1,data.tst.cv)
      LLdiff_all = c(LLdiff_all,LL_loss)
    }
    
    LLdiff_all_cv <- matrix(nrow=K,ncol=(dim(para)[1]/K))
    for (i1 in 1:K) {
      LLdiff_all_cv[i1,] <- LLdiff_all[(nalpha*nlambda*(i1-1)+1):(nalpha*nlambda*i1)]
    }
    
    LLdiff_best_colmean <- colMeans(LLdiff_all_cv)
    LLdiff_best_colmean_mat <- matrix(nrow=nalpha,ncol=nlambda)
    for (i2 in 1:nalpha) {
      LLdiff_best_colmean_mat[i2,] <- LLdiff_best_colmean[(nlambda*(i2-1)+1):(nlambda*i2)]
    }
    
    LLdiff_best <- which(LLdiff_best_colmean_mat==min(LLdiff_best_colmean_mat),arr.ind=T)
    best.alpha <- alpha[LLdiff_best[,1]]
    best.lambda <- lambda[LLdiff_best[,2]]
    
    ## Fit SGL
    Fit <- SGL(data.trn, index, type = "logit", maxit = 1000, thresh = 0.001,
               min.frac = 0.05, nlam = 1, gamma = 0.8, standardize = FALSE,
               verbose = FALSE, step = 1, reset = 10, alpha = best.alpha, 
               lambdas = best.lambda)
    
    a[j,] <- Fit$beta
    beta_raw <- a
    Y_pre[j,] <- predictSGL(Fit, X_tst)
  }#end bootstrap
  for (i in 1:(test_all)) {
    if(sum(Y_pre[,i])>(boot_strap/2)){
      Y_pre.vote[i]<-1
    } else if(sum(Y_pre[,i])<(boot_strap/2)){
      Y_pre.vote[i]<-0
    } else if(sum(Y_pre[,i])==(boot_strap/2)){
      Y_pre.vote[i]<-sample(c(0,1),1)
    }
  }
  
  error.rate1 <- sum((Y_tst[1:test1] - Y_pre.vote[1:test1])^2) / length(Y_tst[1:test1])
  error.rate2 <- sum((Y_tst[(test1+1):(test_all)] - Y_pre.vote[(test1+1):(test_all)])^2)/length(Y_tst[(test1+1):(test_all)])
  
  # compute weight matrix
  beta1=matrix(nrow=boot_strap,ncol=(p*(p-1)*3/2))
  beta2=matrix(nrow=boot_strap,ncol=(p*(p-1)*3/2))
  
  for(b in 1:boot_strap){
    for(i in 1:(3*(p-1)*p/2)){
      beta1[b,i]=beta_raw[b,i]
      beta2[b,i]=beta_raw[b,(i+(3*(p-1)*p/2))]
      if(beta1[b,i]!=0){
        beta1[b,i]=1
      }
      if(beta2[b,i]!=0){
        beta2[b,i]=1
      }
    }
  } 
  
  beta1_sum=colSums(beta1) 
  beta2_sum=colSums(beta2)
  
  beta1_mat <- matrix(nrow = p+1,ncol=p-1)
  for (i in 1:p-1) {
    beta1_mat[,i] <- c(0,beta1_sum[(((p*i)-p+1):(p*i))]) 
  }
  beta1_vec <- c(as.vector(beta1_mat),0)
  beta1_mat_final <- matrix(beta1_vec,nrow=p,ncol=p)
  beta1_sum_vec1 <- (as.vector(beta1_mat_final[upper.tri(beta1_mat_final, diag = FALSE)]))
  beta1_sum_vec2 <- (as.vector(t(beta1_mat_final)[upper.tri(t(beta1_mat_final), diag = FALSE)]))
  beta1_sum_vec3 <- (beta1_sum[(p*(p-1)+1):(3*p*(p-1)/2)])
  beta1_final <- colSums(rbind(beta1_sum_vec1,beta1_sum_vec2,beta1_sum_vec3))
  
  ####data2 
  beta2_mat <- matrix(nrow = p+1,ncol=p-1)
  for (i in 1:p-1) {
    beta2_mat[,i] <- c(0,beta2_sum[(((p*i)-p+1):(p*i))]) 
  }
  beta2_vec <- c(as.vector(beta2_mat),0)
  beta2_mat_final <- matrix(beta2_vec,nrow=p,ncol=p)
  beta2_sum_vec1 <- (as.vector(beta2_mat_final[upper.tri(beta2_mat_final, diag = FALSE)]))
  beta2_sum_vec2 <- (as.vector(t(beta2_mat_final)[upper.tri(t(beta2_mat_final), diag = FALSE)]))
  beta2_sum_vec3 <- (beta2_sum[(p*(p-1)+1):(3*p*(p-1)/2)])
  beta2_final <- colSums(rbind(beta2_sum_vec1,beta2_sum_vec2,beta2_sum_vec3)) 
  
  
  weight.matrix.1 <- matrix(0,nrow = p, ncol = p)
  weight.matrix.1[upper.tri(weight.matrix.1)] <- beta1_final
  weight.matrix.1 <- weight.matrix.1+t(weight.matrix.1)
  
  weight.matrix.2 <- matrix(0,nrow = p, ncol = p)
  weight.matrix.2[upper.tri(weight.matrix.2)] <- beta2_final
  weight.matrix.2 <- weight.matrix.2+t(weight.matrix.2)
  
  # threshold=3*boot_strap/2
  diff.matrix.1 <- matrix(0,nrow = p,ncol = p)
  for (i in 1:p) {
    for (j in 1:p) {
      if(weight.matrix.1[i,j]>threshold){
        diff.matrix.1[i,j] <- 1
      }
    }
  }
  
  diff.matrix.2 <- matrix(0,nrow = p,ncol = p)
  for (i in 1:p) {
    for (j in 1:p) {
      if(weight.matrix.2[i,j]>threshold){
        diff.matrix.2[i,j] <- 1
      }
    }
  }
  

  return(list(diff.matrix.1=diff.matrix.1,weight.matrix.1=weight.matrix.1,
              diff.matrix.2=diff.matrix.2,weight.matrix.2=weight.matrix.2,
              error.rate1=error.rate1,error.rate2=error.rate2))
  
}


