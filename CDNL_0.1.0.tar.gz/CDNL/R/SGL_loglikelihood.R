loglikelihood_SGL = function(x,data.tst.cv){
  cvobj = x
  
  X <- data.tst.cv$x
  Y <- data.tst.cv$y
  newX <- X
  
  if(is.matrix(X)){
    X <- t(t(newX) - x$X.transform$X.means)
    if(!is.null(x$X.transform$X.scale)){
      X <- t(t(X) / x$X.transform$X.scale)
    }
  }
  if(is.vector(X)){
    X <- X - x$X.transform$X.means
    if(!is.null(x$X.transform$X.scale)){
      X <- X / x$X.transform$X.scale
    }  
  }
  
  if(x$type == "logit"){
    intercept <- x$intercept
  }
  
  if(is.matrix(X)){
    eta <- X %*% x$beta + intercept
  }
  if(is.vector(X)){
    eta <- sum(X * x$beta) + intercept
  }
  
  if(x$type == "logit"){
    y.pred = exp(eta)/(1+exp(eta))
    LLdiff <- -sum(Y*log(y.pred)+(1-Y)*log(1-y.pred))
  }
  
  return(LLdiff)
}
